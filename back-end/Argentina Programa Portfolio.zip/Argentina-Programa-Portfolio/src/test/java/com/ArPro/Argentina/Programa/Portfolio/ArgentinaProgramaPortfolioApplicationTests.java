package com.ArPro.Argentina.Programa.Portfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArgentinaProgramaPortfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
