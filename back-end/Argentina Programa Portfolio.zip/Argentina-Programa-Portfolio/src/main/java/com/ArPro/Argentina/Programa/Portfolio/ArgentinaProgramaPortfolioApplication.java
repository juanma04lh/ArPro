package com.ArPro.Argentina.Programa.Portfolio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArgentinaProgramaPortfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArgentinaProgramaPortfolioApplication.class, args);
	}

}
